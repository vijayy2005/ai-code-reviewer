# AI Code Reviewer

Starter project for internship.
