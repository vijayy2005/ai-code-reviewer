def analyze(code):
    return {"issues": [], "complexity": "N/A"}
