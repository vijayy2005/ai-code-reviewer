import streamlit as st

st.set_page_config(page_title="AI Code Reviewer")
st.title("AI Code Reviewer")
code = st.text_area("Paste Python code")
if st.button("Analyze"):
    st.code(code)
    st.success("This starter template is ready for flake8, black, and radon integration.")
